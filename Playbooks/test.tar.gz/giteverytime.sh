#!/bin/bash
sudo git add Playbooks/*
sudo git commit -m "first commit"
git remote add origin https://github.com/akhileshjoshi2/ansible-modules.git
git push -u origin master

