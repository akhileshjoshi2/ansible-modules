#!/bin/bash
/bin/uptime
