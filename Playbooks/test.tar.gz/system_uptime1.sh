#!/bin/bash
/bin/uptime > /home/test/uptime.log
